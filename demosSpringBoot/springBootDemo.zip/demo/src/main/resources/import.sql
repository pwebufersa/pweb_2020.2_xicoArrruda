insert into contatos (id, nome, email) values (1, 'William Douglas', 'williamdouglas@algaworks.com');
insert into contatos (id, nome, email) values (2, 'Al Ries', 'alries@algaworks.com');
insert into contatos (id, nome, email) values (3, 'Mortimer J. Adler', 'mortimeradler@algaworks.com');
insert into contatos (id, nome, email) values (4, 'Christian Barbosa', 'christianbarbosa@algaworks.com');